import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import ttk

def fetch_sunspot_data():
    url = "https://www.sidc.be/SILSO/DATA/SN_m_tot_V2.0.txt"
    df = pd.read_csv(
        url,
        sep=r"\s+",
        header=None,
        comment='#',
        names=["Year", "Month", "DateFraction", "SunspotNumber", "StdDev", "Observations", "Definitive"]
    )
    df["Date"] = pd.to_datetime(dict(year=df.Year, month=df.Month, day=1))
    df["Year"] = df["Date"].dt.year
    return df

sunspot_df = fetch_sunspot_data()
annual_df = sunspot_df.groupby("Year").mean(numeric_only=True).reset_index()

cycle_start_years = {
    1: 1755, 2: 1766, 3: 1775, 4: 1784, 5: 1798, 6: 1810,
    7: 1823, 8: 1833, 9: 1843, 10: 1855, 11: 1867, 12: 1878,
    13: 1890, 14: 1902, 15: 1913, 16: 1923, 17: 1933, 18: 1944,
    19: 1954, 20: 1964, 21: 1976, 22: 1986, 23: 1996, 24: 2008, 25: 2019
}

def plot_sunspot(start_date, end_date):
    start_year = pd.to_datetime(start_date).year
    end_year = pd.to_datetime(end_date).year
    df = annual_df[(annual_df["Year"] >= start_year) & (annual_df["Year"] <= end_year)]

    plt.figure(figsize=(14, 6))
    plt.plot(df["Year"], df["SunspotNumber"], color="orange", linewidth=2)
    plt.title(f"Güneş Lekesi Sayısı ({start_year} - {end_year})")
    plt.xlabel("Yıl")
    plt.ylabel("Ortalama Güneş Lekesi Sayısı")
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()
    plt.show()

def generate_butterfly(df, cycles):
    all_dates = []
    all_latitudes = []

    for cyc_num, start_year in cycles.items():
        end_year = cycles.get(cyc_num + 1, 2025)
        start = pd.Timestamp(f"{start_year}-01-01")
        end = pd.Timestamp(f"{end_year}-01-01")
        mask = (df["Date"] >= start) & (df["Date"] < end)
        cyc_df = df.loc[mask]

        for _, row in cyc_df.iterrows():
            date = row["Date"]
            intensity = row["SunspotNumber"]
            if pd.isna(intensity) or intensity <= 0:
                continue

            t = (date - start).days / ((end - start).days + 1e-9)
            center_lat = 35 * (1 - t) + 5 * t
            count = int(intensity / 5)

            lat_n = center_lat + np.random.normal(0, 2, count)
            lat_s = -center_lat + np.random.normal(0, 2, count)
            dates = [date] * count

            all_dates += dates + dates
            all_latitudes += list(lat_n) + list(lat_s)

    return pd.DataFrame({"Date": all_dates, "Latitude": all_latitudes})

butterfly_df = generate_butterfly(sunspot_df, cycle_start_years)

def plot_butterfly(start_date, end_date):
    start = pd.to_datetime(start_date)
    end = pd.to_datetime(end_date)
    df = butterfly_df[(butterfly_df["Date"] >= start) & (butterfly_df["Date"] <= end)]

    plt.figure(figsize=(15, 7))
    plt.scatter(df["Date"], df["Latitude"], s=2, c=df["Latitude"], cmap="coolwarm", alpha=0.6)
    plt.axhline(0, color='gray', linestyle='--', linewidth=0.5)
    plt.title(f"Kelebek Diyagramı ({start.year} – {end.year})")
    plt.xlabel("Tarih")
    plt.ylabel("Enlem (°)")
    plt.colorbar(label="Enlem (°)")
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.show()

def draw():
    mode = mode_var.get()
    if mode == "Tarih Aralığı":
        start = entry_start.get()
        end = entry_end.get()
        if graph_type.get() == "Güneş Lekesi":
            plot_sunspot(start, end)
        else:
            plot_butterfly(start, end)
    else:
        cycle = int(entry_cycle.get())
        start = f"{cycle_start_years[cycle]}-01-01"
        end_year = cycle_start_years.get(cycle + 1, 2025)
        end = f"{end_year}-01-01"
        if graph_type.get() == "Güneş Lekesi":
            plot_sunspot(start, end)
        else:
            plot_butterfly(start, end)

root = tk.Tk()
root.title("Güneş Çevrimleri ve Kelebek Diyagramı")

ttk.Label(root, text="Mod Seçin:").grid(column=0, row=0, sticky="w")
mode_var = tk.StringVar(value="Tarih Aralığı")
ttk.Combobox(root, textvariable=mode_var, values=["Tarih Aralığı", "Çevrim Numarası"]).grid(column=1, row=0)

ttk.Label(root, text="Başlangıç Tarihi (YYYY-MM-DD):").grid(column=0, row=1, sticky="w")
entry_start = ttk.Entry(root)
entry_start.insert(0, "2000-01-01")
entry_start.grid(column=1, row=1)

ttk.Label(root, text="Bitiş Tarihi (YYYY-MM-DD):").grid(column=0, row=2, sticky="w")
entry_end = ttk.Entry(root)
entry_end.insert(0, "2025-01-01")
entry_end.grid(column=1, row=2)

ttk.Label(root, text="Çevrim No (1–25):").grid(column=0, row=3, sticky="w")
entry_cycle = ttk.Entry(root)
entry_cycle.insert(0, "24")
entry_cycle.grid(column=1, row=3)

ttk.Label(root, text="Grafik Türü:").grid(column=0, row=4, sticky="w")
graph_type = tk.StringVar(value="Güneş Lekesi")
ttk.Combobox(root, textvariable=graph_type, values=["Güneş Lekesi", "Kelebek Diyagramı"]).grid(column=1, row=4)

ttk.Button(root, text="Grafiği Göster", command=draw).grid(column=0, row=5, columnspan=2, pady=10)

root.mainloop()
