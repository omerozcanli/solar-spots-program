# Güneş Çevrimleri ve Kelebek Diyagramı Arayüzü

Bu Python GUI uygulaması, SILSO verilerini kullanarak:
- Güneş lekesi sayısının yıllara göre değişimi
- Kelebek diyagramı (leke konumlarının zamana göre dağılımı)

grafiklerini çizmenizi sağlar.

## Kullanım

```bash
pip install -r requirements.txt
python solar_gui.py
```

## Özellikler
✅ Çevrim numarasına göre grafik  
✅ Tarih aralığına göre görselleştirme  
✅ Güneş lekesi veya kelebek diyagramı seçimi
